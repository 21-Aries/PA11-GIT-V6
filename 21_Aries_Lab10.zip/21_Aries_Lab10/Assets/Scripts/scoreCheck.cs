﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class scoreCheck : MonoBehaviour
{
    public float Score;
    public Text scoretxt;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider Other)
    {
        if (Other.gameObject.tag == "Obstacle")
        {
            Destroy(Other.gameObject);
            Score++;
            scoretxt.text = "Score :" + Score;
        }
    }
}
